package com.example.gio.listviewsample;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends Activity {

    StudentAdapter adapter;
    ListView lvDemo;
    private ArrayList<Student> listData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvDemo = (ListView) findViewById(R.id.lvDemo);

//        //khoi tao du lieu cho mang duoc hien thi
//        arrData = new String[]{"Phan Van Hoai","Phan Trong Nhan","Vo duy Linh", "nguyen Hoang","Pham Hung"};
        //Khởi tạo danh sách các sinh viên
        createData();

        //khoi tao adapter
//        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arrData);
        adapter = new StudentAdapter(this, listData);
        //dua adapter vao listview
        lvDemo.setAdapter(adapter);

        adapter.notifyDataSetChanged();
    }

    private void createData(){
        listData = new ArrayList<>();
        for (int i=0; i < 10; i++){
            listData.add(new Student(i, "Phan Văn Hoài " + i, "0985936754 " + i));
        }
    }
}
