package com.example.gio.listviewsample;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Gio on 1/4/2017.
 */

public class StudentAdapter extends BaseAdapter{
    ArrayList<Student> listData;
    LayoutInflater inflater;

    //Hàm tạo của custom
    public StudentAdapter(Context context,ArrayList<Student> listData){
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.listData = listData;

    }

    //trả về sô lượng phần tử được hiển thị trong listView
    @Override
    public int getCount() {
        return listData.size();
    }

    //Trả về đối tượng được lấy theo vị trí
    @Override
    public Object getItem(int position) {
        return listData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }


    //Hiển thị giao diện của ListView
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //Lấy ra đối tượng cần hiển thị ở vị trí thứ position
        Student item = listData.get(position);
        //Khai báo các component
        TextView txtName, txtPhone;
        //Khởi tạo View
        if (convertView==null){
            convertView = inflater.inflate(R.layout.list_view,parent,false);
        }

        txtName = (TextView) convertView.findViewById(R.id.txtName);
        txtPhone = (TextView) convertView.findViewById(R.id.txtPhone);
        txtName.setText(item.getName());
        txtPhone.setText(item.getPhone());
        return convertView;
    }
}
