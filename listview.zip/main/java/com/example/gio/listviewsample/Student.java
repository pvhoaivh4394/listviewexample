package com.example.gio.listviewsample;

/**
 * Created by Gio on 1/4/2017.
 */

public class Student {
    private int id;
    private String Name;
    private String Phone;

    public Student(int id, String name, String phone) {
        this.id = id;
        Name = name;
        Phone = phone;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        Name = name;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getName() {

        return Name;
    }

    public String getPhone() {
        return Phone;
    }
}
